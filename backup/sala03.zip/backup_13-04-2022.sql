#
# TABLE STRUCTURE FOR: app_content
#

DROP TABLE IF EXISTS `app_content`;

CREATE TABLE `app_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `conteudo` varchar(700) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_content` (`id`, `titulo`, `conteudo`) VALUES (1, 'A SALA 03', 'Criado em 2014, SALA03 é a consolidação de profissionais que trabalham juntos há mais de dez anos. O escritório surgiu com o objetivo de oferecer a cada cliente um serviço completo, centralizando num único lugar e equipe a criação de projeto arquitetônico, interiores e a administração da obra.\r\n\r\nA fusão do projeto arquitetônico à natureza! O estilo SALA03 é contemporâneo, onde “menos é mais”, simplicidade em voga e o uso inteligente de materiais. Prezamos pela privacidade de quem vai ocupar esses lares, fluidez aos ambientes e, acima de tudo, projetos para pessoas');


#
# TABLE STRUCTURE FOR: app_funcionarios
#

DROP TABLE IF EXISTS `app_funcionarios`;

CREATE TABLE `app_funcionarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `foto_funcionario` varchar(70) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (1, 'Pedro Antunes', 'Engenheiro Civil', '4bad3ebedabf7d66450d7b1dbf9a8ce8.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (2, 'Giovanna Passador', 'Arquiteta Urbanista', '3f0bf1b52a4a1d099870552e0eff4f11.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (3, 'Gabriel Curci', 'Arquiteto Urbanista', 'e41352cd32b1314bd53ca55517e0e1f3.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (4, 'Jaqueline Miranda', 'Arquiteta Urbanista', '1873955c25124140fe013c77c53782a2.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (5, 'Marcelo Moretti', 'Arquiteto Urbanista', '26a112f4258aac480445b1ad19c8ccf9.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (6, 'Augusto Antunes', 'Arquiteto Urbanista', 'e764807fcdda256a958d40106be8d643.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (8, 'Fernanda Barreiros', 'Arquiteta Urbanista', 'fe2593060c70263460aac81b96928267.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (9, 'Júlia Arnsten', 'Arquiteta Urbanista', '68a70c00c6d66240a952d4493a6e74d3.jpg', 1);


#
# TABLE STRUCTURE FOR: app_gallery
#

DROP TABLE IF EXISTS `app_gallery`;

CREATE TABLE `app_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_app_projects` varchar(50) COLLATE utf8_bin NOT NULL,
  `titulo_galeria` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `fotos` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_gallery` (`id`, `id_app_projects`, `titulo_galeria`, `fotos`) VALUES (1, 'CASA D A', 'Galeria - Casa D A', 'ab69f26ec45f52f217871625cd2988fa.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `titulo_galeria`, `fotos`) VALUES (2, 'CASA D A', 'Galeria - Casa D A', 'ad2f51b4b516300e08f603a6a88fdc45.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `titulo_galeria`, `fotos`) VALUES (3, 'CASA D A', 'Galeria - Casa D A', '1fa01ccbdd776746e770d1f5f9e69b75.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `titulo_galeria`, `fotos`) VALUES (4, 'CASA D A', 'Galeria - Casa D A', '910a76417f21e65625297d4f17969020.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `titulo_galeria`, `fotos`) VALUES (5, 'CASA D A', 'Galeria - Casa D A', 'e11c4e290f12015c3c6a18689d684b32.jpg');


#
# TABLE STRUCTURE FOR: app_home
#

DROP TABLE IF EXISTS `app_home`;

CREATE TABLE `app_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `legenda_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banner_imagem` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (1, 'Banner #1', 'Banner Teste', '3963e333e3c60a4baedc6d2a5d360cf0.jpg', 1);
INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (3, 'Banner #2', 'Banner Teste', 'f8b9ceae978beaa4caf4bbdbffb6f163.jpg', 1);


#
# TABLE STRUCTURE FOR: app_projects
#

DROP TABLE IF EXISTS `app_projects`;

CREATE TABLE `app_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ficha_tecnica` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `localizacao` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `equipe` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `categoria_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `destaque` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (1, 'CASA R L ', 'Terreno: 2006,00m²\r\nÁrea Construída: 600,00m²', 'Itu / São Paulo', 'Cauê Baldi\r\nJoão Osorio\r\nMarcelo Moretti\r\nFernanda Barreiros\r\nGabriel Curci\r\nCatarina Roland\r\nJaqueline Miranda\r\nMaria Luiza Del Rio\r\nJosé Victor Godoi\r\nGiovanna Passador\r\nMariana Gomes\r\nJulia Arntsen\r\nIanca Carvalho\r\nPedro Antunes', 'Design - Interiores', '7988bc90c322a25a7d832dc18e6211e3.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (2, 'CASA D A', 'Terreno: 503,20m²\r\nÁrea Construída: 355,00m²', 'Itu / São Paulo', 'Cauê Baldi\r\nJoão Osorio\r\nMarcelo Moretti\r\nFernanda Barreiros\r\nGabriel Curci\r\nCatarina Roland\r\nJaqueline Miranda\r\nMaria Luiza Del Rio\r\nJosé Victor Godoi\r\nGiovanna Passador\r\nMariana Gomes\r\nJulia Arntsen\r\nIanca Carvalho\r\nPedro Antunes', 'Interiores - Design - Casas', '671ab7e3ba061f306dcc091c850a154c.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (3, ' CASA B A', 'Terreno: 2123,43m²\r\nÁrea Construída: 710,00m²', 'Itu / São Paulo', 'Cauê Baldi\r\nJoão Osorio\r\nMarcelo Moretti\r\nFernanda Barreiros\r\nGabriel Curci\r\nCatarina Roland\r\nJaqueline Miranda\r\nMaria Luiza Del Rio\r\nJosé Victor Godoi\r\nGiovanna Passador\r\nMariana Gomes\r\nJulia Arntsen\r\nIanca Carvalho\r\nPedro Antunes', 'Interiores - Design - Construção', 'e37b7ec27be893815be2f86114353ddc.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (4, 'CASA G M', 'Terreno: 2781,50m²\r\nÁrea Construída: 1045,00m²', 'Itu / São Paulo', 'Cauê Baldi\r\nJoão Osorio\r\nMarcelo Moretti\r\nFernanda Barreiros\r\nGabriel Curci\r\nCatarina Roland\r\nJaqueline Miranda\r\nMaria Luiza Del Rio\r\nJosé Victor Godoi\r\nGiovanna Passador\r\nMariana Gomes\r\nJulia Arntsen\r\nIanca Carvalho\r\nPedro Antunes', 'Design - Interiores', 'c2fc68b6b89fcf1e87f2052bfb27f31b.jpg');


#
# TABLE STRUCTURE FOR: app_usuarios
#

DROP TABLE IF EXISTS `app_usuarios`;

CREATE TABLE `app_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `senha` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_usuarios` (`id`, `nome`, `email`, `senha`, `ativo`) VALUES (3, 'Igor ', 'igor@agenciaduetto.com.br', 'ad108b78d9733dbdf783007c88a08282c9bca427', 1);


