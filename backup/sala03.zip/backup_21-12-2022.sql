#
# TABLE STRUCTURE FOR: app_content
#

DROP TABLE IF EXISTS `app_content`;

CREATE TABLE `app_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `citacao` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `conteudo` varchar(700) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_content` (`id`, `titulo`, `citacao`, `conteudo`) VALUES (1, 'SALA 03', 'Um trabalho colaborativo que tem um único objetivo: a excelência em cada projeto.', '<b>VOCÊ é nossa maior inspiração!</b> <br>\r\nNão há nada mais inspirador do que o material humano, suas histórias, seus hábitos, cotidiano e a trajetória percorrida até a concepção de um projeto que, futuramente, será <b>chamado de LAR</b>. Para nós, do SALA03, participar de um capítulo de histórias de vida é o combustível para fazer nosso trabalho de forma única. Afinal, estamos falando sobre construir um local que será o cenário principal da vida de uma família, abrigando momentos inesquecíveis.');


#
# TABLE STRUCTURE FOR: app_funcionarios
#

DROP TABLE IF EXISTS `app_funcionarios`;

CREATE TABLE `app_funcionarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `foto_funcionario` varchar(70) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (11, 'Marcelo Moretti', 'Coordenador Comercial', 'aebde1b8b6663a8193f75b99961a40eb.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (12, 'Pedro Antunes', 'Engenheiro - Obras', 'e02821d293d06c21cb19fc3371cf88f5.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (13, 'Giovanna Passador', 'Arquiteta', 'acbcc0b230f21044c5b1985ff2e5f6c4.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (14, 'Gabriel Curci', 'Coordenador de Arquitetura', 'bc923351f87d2584f5a1e12269f8837c.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (15, 'Augusto Mantovani', 'Engenheiro - Obras', '67d72d31215bd6e7083c36b04ef85dc3.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (16, 'Fernanda Barreiros', 'Coordenadora de Interiores', '7e09b3aef1161bb8438e3dbf23d5dfd2.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (17, 'Catarina Roland', 'Coordenadora de Arquitetura', '7ef2a566bedc666cb5679e14054bd037.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (18, 'Daniel Santos', 'Arquiteto - Obras', '810d63c5ea2663a8c62cf3b41ae6fe1a.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (19, 'Júlia Arntsen', 'Arquiteta - Interiores', 'c089f14be12dbb3a6e69d0f0b0d1c8cc.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (20, 'José Victor Cutait', 'Arquiteto', '05f57a6709762c66cda2338860578889.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (21, 'Lorena Borges', 'Supervisora de Interiores', '5479349b362ede8ddb3ae76e69361c8c.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (23, 'Jéssica Braga', 'Arquiteta - Interiores', '19c83b4b37e20d75f401367bf1c49bc7.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (24, 'Ana Clara Gizeria', 'Arquiteta - Interiores', '4f9be17f893de72318b15687259c3371.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (25, 'Ianca Carvalho', 'Arquiteta - Interiores', '94be551e2d92f0c4191da0dadb6579d4.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (26, 'Jaíne Vargas', 'Arquiteta - Interiores', 'bcd7e6cc3cba6baa1e4f08d32c35a404.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (27, 'Maria Luiza Del Rio', 'Arquiteta', 'f645df327423eb83dd60ad72364a85d0.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (29, 'Lucas Vieira', 'Arquiteto ', 'e0cfbf57fb09c29d13890ef3d3d39a4a.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (30, 'Katia Souza', 'Financeiro', '4c48a3d78ebae57c6387be39710ccdec.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (31, 'Juliana Ferraz', 'Financeiro', '4b32baca0e3bc8ab4f8a9b427bca6097.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (32, 'Louis', 'Mascote Oficial do Escritório', '50c689f06365e043cf80301e28c33b21.jpg', 1);


#
# TABLE STRUCTURE FOR: app_gallery
#

DROP TABLE IF EXISTS `app_gallery`;

CREATE TABLE `app_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_app_projects` varchar(50) COLLATE utf8_bin NOT NULL,
  `fotos` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (30, '7', '3d11e228f919ab4ea459c1278183cbc0.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (31, '7', 'd08723a5798cdfc7097f62ad66b12e18.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (32, '7', '48cc5c23b9a12d386b45714acaa06ef5.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (33, '8', '71661ff3ebdd09b4c65407717eda6cbb.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (34, '8', '25a4fb73504f2d5b8c34f4bf86cf559b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (35, '8', '18be28f755d1ed5eeeca92d91fd2d54b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (36, '9', '52d036d8691ec469b794781db86a5dc8.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (37, '9', '2003607245939e888b0d2b42a4e309fe.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (38, '9', '57a62c87ee1591f5de43e7474c1f9aed.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (39, '10', 'd90bd37b7d4ef7563fabd8adad09ddfa.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (40, '10', 'c36fd3b1f3fb3987da1a7f665750e5e7.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (41, '10', '2994261bc924cc053a3cfcfb61f0d0ad.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (42, '11', '85e6967ca18f16424c9f7e3e47c35e30.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (43, '11', '0c65ceaf96173f3b989730ebe3767020.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (44, '11', '08a580b6fa80180f5aa755129ccd427f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (45, '12', 'bd16392fdbe60adadfa86bec69e65e9d.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (46, '12', '32f835fd4fbcd59f59af318a730e5757.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (47, '12', '140ea7de1bcf82e799c8724543e78cb7.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (48, '14', 'f8a473e11b22f295ee395062b28ddf8c.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (49, '14', '2c455bf004c218eb47669db6cafdb8ac.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (50, '14', 'd6544a610d2d68fd6eb3d54d34e45199.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (51, '14', 'c78f7446f6bcc0048bee1d51bc9f3e8d.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (52, '14', '86d64c8c1b26afea8b66be50440df2d9.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (53, '14', 'e87b10ceafa7839ccadaef05cde4aeb4.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (54, '15', '1f7ed36c20e3156b5130f6a4bcb817c2.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (55, '15', 'a085845d628f2ddfa7292c1f63ae3ac0.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (56, '15', '5a40c8deec4663ed060d3014dcb106dc.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (57, '15', 'bbdba412ba6b57c91a08b38de9e45ff6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (58, '15', '9543e689fa711c85dd9dd41e57a9194e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (59, '15', 'f12110ef90c6214f0b71080f4bdd499c.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (60, '15', 'b82b2adbb674700a8a3d5430c9e6fde6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (61, '16', '3069151b52513c2dab8a309a05619786.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (62, '16', '90cd59311e0dd31e2efb80865d84562f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (63, '16', '8e6cdce5d23c994cd53cbc545e5d2199.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (64, '16', 'eca3b86defd147873cbffc108bf0377b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (65, '16', '1b3e14f10c988bea48414243806d649a.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (66, '16', '372f7b002533d3a063204cd7644de592.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (67, '16', '2ac3b4d31a19cc185afbc3e6a1b33689.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (68, '17', '60e6584c53741f35c5047566a6683a85.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (69, '17', '3b91b7575eca20ad5227aa111a83bd6e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (70, '17', '89939831df414fd2c86e01e53e7ccf3c.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (71, '17', '758b3cd1e20a24b04a1b3c8eb1ff34ac.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (72, '17', '177928cbcd91c3688c529c7fe1c08a8e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (73, '18', 'f1a93fac993ee44a5c5cd8497d4caf67.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (74, '18', '455384613828944c3ae9a0d26824adf3.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (75, '18', 'f5315fdd3f0e47ec8c01a33537443ae1.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (76, '18', '32c96771629e4afca8ac24d71387273a.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (77, '18', '976fe584b8eba477ef56c2cfd0f93db7.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (78, '19', '7cf470becebec3646b9d9799727a340f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (79, '19', '3cc534cf632da1c17ee892cf544b9805.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (80, '19', '7eb7ae124dbb2bed08984a60ebe9f5ff.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (81, '19', 'e18dd0852f99d9382373f7e9587b3a2b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (82, '19', 'a87ef7515663551abf89c7fa11bec703.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (83, '19', '70fc9268ce95982a6bb07c5faf975ec1.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (84, '20', '580431782982b041892bf28d46635848.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (85, '20', '9c3bb93a2add433820d391f15834d8c9.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (86, '20', 'ca746be884eeced735b5f0c4d7ca86a1.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (87, '20', '7ef6fd8b1b5536a7f96aa3278b64b817.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (88, '20', '956d978af42cc89d2cd945a04c7121a3.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (89, '20', '03e2fe53dce587515e0c50323209db0f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (90, '21', '802f4b7d1ef498cb71fb09266148f8dd.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (91, '21', '8eb362c77c16cc6f5744c143743e9673.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (92, '21', 'a0f50af08615088ec42462b970d25cc5.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (93, '21', '90d4623340b0fe83c00b8170d52f32d4.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (94, '21', '3b192d543349d0878db4a05a111fa86c.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (95, '22', '3cff3b1b28007f133c9f1a7753c754ac.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (96, '22', 'b8938acf54c01a7256a85890166af5cf.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (97, '22', 'ee00a6d303723ad2ffb8a92b41fcbbef.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (98, '22', 'a25875ec59d638a094650db64bc038f6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (99, '22', 'a46d1d36067c494f58693387aa3d6908.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (100, '23', 'da40aa55408c117842de6ba33437d833.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (101, '23', 'f7c851904693fd8bedcb28924a24298f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (102, '23', 'ece8b7c5cb46563e9d42738df484170d.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (103, '23', 'ab58765619fb4bd33e6dd5bb5a75461a.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (104, '23', '5818997bc6d5f162d09cb94f00d8339a.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (105, '24', 'c09f0eaace61525dd2236fe871f1c753.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (106, '24', '771735adc027e3eb0fe6dc159e3148ad.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (107, '24', '305f08c74a6469c13e004f48e69da87e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (108, '24', '0e8934d0b7c2731a78726ed80b69e41e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (109, '24', 'f73eb3049b1f597eb357b76b0bc53534.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (110, '24', 'f095b2707891d0d8ea00ab89d90bf494.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (111, '24', '9e6bf2a86f0f53aa0088ef9643a15243.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (112, '25', '8ed02f8ed9b4c92017f5494bc5256dc9.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (113, '25', '72673ff65d8f52a36b10c36cd650f6aa.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (114, '25', '18d8c7649ddd347feb0565bc7d1b2927.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (115, '25', 'd96812d588ad7d8512f728140f7ec548.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (116, '25', '02e9df043375f479a9f580dd8c65f8d6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (117, '25', '1dac20a8840d8437960400d7fdbba98d.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (118, '25', '4f22bbe29ed2b6c3e999bdc8a4c9bbd4.jpg');


#
# TABLE STRUCTURE FOR: app_home
#

DROP TABLE IF EXISTS `app_home`;

CREATE TABLE `app_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `legenda_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banner_imagem` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (4, 'Banner #1', 'Casa Jardineiras', 'a47c7e9f0ea3a193083243fb38b9e0c5.jpg', 1);
INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (6, 'Banner #3', 'Casa 53', 'fb4e0f18ca7f8e902eef4eed9c19c6b3.jpg', 1);
INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (7, 'Banner #4', 'Vila Art', 'd1ac8d7ebd12e3c4ea15370e979046e2.jpg', 1);
INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (8, 'Banner #4', 'Casa das Árvores', '0e2522ae88398eadcbff39202a560b85.jpg', 1);


#
# TABLE STRUCTURE FOR: app_projects
#

DROP TABLE IF EXISTS `app_projects`;

CREATE TABLE `app_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ficha_tecnica` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `localizacao` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `equipe` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `categoria_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `destaque` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  `url_seo` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (7, 'CASA DAS ÁRVORES', 'Área do Terreno: 2.000m² <br>\r\nÁrea Construída: 630m² <br>\r\nDestaque Arch Daily', 'Itu/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Projeto de Arquitetura', '1818988115025b4d01a69c4114def2a7.jpg', 'casa-das-arvores');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (9, 'CASA DA MATA', 'Área do Terreno: 3.020 m² <br>\r\nÁrea Construída: 1.290 m² <br>\r\n', 'Itu/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador<br>\r\nMariana Gomes<br>\r\nJulia Arntsen <br>\r\nIanca Carvalho<br>\r\nPedro Antunes<br>', 'Projeto de Arquitetura', '74c164d446a65b7663c5b5bf812a5422.jpg', 'casa-da-mata');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (10, 'CASA RELAX', 'Área do Terreno: 2.124m² <br>\r\nÁrea Construída: 640m² <br>', 'Itu/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador<br>\r\nMariana Gomes<br>\r\nJulia Arntsen <br>\r\nIanca Carvalho<br>\r\nPedro Antunes<br>', 'Projeto de Arquitetura', '55ada2f01881442cd2872ff006d31aec.jpg', 'casa-relax');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (11, 'CASA GAMELEIRAS', 'Área do Terreno: 2.790m² <br>\r\nÁrea Construída: 730m² <br>', 'Itu/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Projeto de Arquitetura', '4e776d0e9fb3312b467206ce634dde87.jpg', 'casa-gameleiras');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (12, 'CASA JANDAYAS', 'Área do Terreno: 3.040m² <br>\r\nÁrea Construída: 730m²', 'Itu/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Projeto de Interiores', 'd5be9df80547a8567b4852ca7693b3bc.jpg', 'casa-jandayas');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (14, 'CASA VILLA ART', 'Área do Terreno: 3.320 m² <br>\r\nÁrea Construída: 1.905 m²', 'PORTO FELIZ/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '326c35f1c269fd3588394d05ea62e90f.jpg', 'casa-villa-art');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (15, 'CASA VIK', 'Área do Terreno: 3.340 m² <br>\r\nÁrea Construída:   950 m²', 'Bragança Paulista/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '29a4ac4560e77ed68f4db7e311289e7d.jpg', 'casa-viu');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (16, 'CASA IKIGAI', 'Área do Terreno: 2.825 m² <br>\r\nÁrea Construída:   970 m²\r\n', 'ITUPEVA/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '924c1fd94c859c3897d05cd4c3b05070.jpg', 'casa-ikgai');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (17, 'CASA 2ZS', 'Área do Terreno: 2.400 m² <br>\r\nÁrea Construída:   880 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '08b9ba7699eda378a1fdc7a679e7d9ac.jpg', 'casa-2zs');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (19, 'CASA JARDINEIRAS', 'Área do Terreno: 2.660 m² <br>\r\nÁrea Construída:   910 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA E INTERIORES', 'e2de5cf784bb6ff61d12043c461698d2.jpg', 'casa-jardineiras');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (20, 'CASA BIALE', 'Área do Terreno: 2.120 m² <br>\r\nÁrea Construída:   700 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA E INTERIORES', '26aa0d0ac619f5d6facba9c8a07cbdbb.jpg', 'casa-biale');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (21, 'CASA SORELLE 05', 'Área do Terreno: 2.160 m²\r\nÁrea Construída: 885 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA E INTERIORES', '8058b08b75fef76f69cdfce53c8ead14.jpg', 'casa-sorelle-05');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (22, 'CASA SORELLE 06', 'Área do Terreno: 2.070 m² <br>\r\nÁrea Construída:   695 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA E INTERIORES', '7d0b06adfd6e925af86ddce032362114.jpg', 'casa-sorelle-06');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (23, 'CASA QUADRADO', 'Área do Terreno: 3.040 m² <br>\r\nÁrea Construída:   710 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '85dc793ba3ba3cb22d3df3d4beb57974.jpg', 'casa-quadrado');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (24, 'CASA MSL', 'Área do Terreno: 1.035 m² <br>\r\nÁrea Construída:   420 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE INTERIORES', '62bb9edac4bac0cb26aaa361db08ba61.jpg', 'casa-msl');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`, `url_seo`) VALUES (25, 'CASA DOM', 'Área do Terreno: 5.300 m² <br>\r\nÁrea Construída: 1.360 m²', 'ITU/SP', 'Cauê Baldi <br>\r\nJoão Osório <br>\r\nMarcelo Moretti <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nLucas Vieira <br>\r\nFernanda Barreiros <br>\r\nLorena Borges <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nJéssica Braga <br>\r\nAna Clara Gizeria <br>\r\nJaíne Vargas <br>\r\nPedro Antunes <br>\r\nDaniel dos Santos <br>\r\nAugusto Mantovani ', 'PROJETO DE ARQUITETURA', '1c947a46750c66bb364d00b47ddb6b5e.jpg', 'casa-dom');


#
# TABLE STRUCTURE FOR: app_usuarios
#

DROP TABLE IF EXISTS `app_usuarios`;

CREATE TABLE `app_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `senha` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_usuarios` (`id`, `nome`, `email`, `senha`, `ativo`) VALUES (3, 'Igor ', 'igor@agenciaduetto.com.br', 'ad108b78d9733dbdf783007c88a08282c9bca427', 1);
INSERT INTO `app_usuarios` (`id`, `nome`, `email`, `senha`, `ativo`) VALUES (4, 'Vitor Maia', 'vitor@agenciaduetto.com.br', 'f9cdb8fcf9f339f2f5aa714d3dfbeeb9c0cb81d3', 1);
INSERT INTO `app_usuarios` (`id`, `nome`, `email`, `senha`, `ativo`) VALUES (5, 'Marcelo Moretti', 'marcelomoretti@sala03.arq.br', 'f19d705f4b869d766b48611d842a5e1bdbacebe3', 1);


