#
# TABLE STRUCTURE FOR: app_content
#

DROP TABLE IF EXISTS `app_content`;

CREATE TABLE `app_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `conteudo` varchar(700) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_content` (`id`, `titulo`, `conteudo`) VALUES (1, 'A SALA 03', 'Criado em 2014, SALA03 é a consolidação de profissionais que trabalham juntos há mais de dez anos. O escritório surgiu com o objetivo de oferecer a cada cliente um serviço completo, centralizando num único lugar e equipe a criação de projeto arquitetônico, interiores e a administração da obra.\r\n\r\nA fusão do projeto arquitetônico à natureza! O estilo SALA03 é contemporâneo, onde “menos é mais”, simplicidade em voga e o uso inteligente de materiais. Prezamos pela privacidade de quem vai ocupar esses lares, fluidez aos ambientes e, acima de tudo, projetos para pessoas');


#
# TABLE STRUCTURE FOR: app_funcionarios
#

DROP TABLE IF EXISTS `app_funcionarios`;

CREATE TABLE `app_funcionarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `cargo_funcionario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `foto_funcionario` varchar(70) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (1, 'Pedro Antunes', 'Engenheiro Civil', '4bad3ebedabf7d66450d7b1dbf9a8ce8.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (2, 'Giovanna Passador', 'Arquiteta Urbanista', '3f0bf1b52a4a1d099870552e0eff4f11.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (3, 'Gabriel Curci', 'Arquiteto Urbanista', 'e41352cd32b1314bd53ca55517e0e1f3.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (4, 'Jaqueline Miranda', 'Arquiteta Urbanista', '1873955c25124140fe013c77c53782a2.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (5, 'Marcelo Moretti', 'Arquiteto Urbanista', '26a112f4258aac480445b1ad19c8ccf9.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (6, 'Augusto Antunes', 'Arquiteto Urbanista', 'e764807fcdda256a958d40106be8d643.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (8, 'Fernanda Barreiros', 'Arquiteta Urbanista', 'fe2593060c70263460aac81b96928267.jpg', 1);
INSERT INTO `app_funcionarios` (`id`, `nome_funcionario`, `cargo_funcionario`, `foto_funcionario`, `ativo`) VALUES (9, 'Júlia Arnsten', 'Arquiteta Urbanista', '68a70c00c6d66240a952d4493a6e74d3.jpg', 1);


#
# TABLE STRUCTURE FOR: app_gallery
#

DROP TABLE IF EXISTS `app_gallery`;

CREATE TABLE `app_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_app_projects` varchar(50) COLLATE utf8_bin NOT NULL,
  `fotos` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (1, '1', 'a03c620d7fca2d02e8e03dca11904a30.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (2, '1', 'fb98b780a3d0d4ba32bf17bea65bab11.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (3, '1', '547dbe0473808fc0b171a7a91d4f4bb9.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (4, '1', '8aed37cc8b791f64a481326e84f3031b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (5, '1', 'de0ad414cfa3dad43235511170ce3af3.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (6, '1', '89877eb8e4eb8974ace020a491caaa41.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (8, '2', '90500eb8c852855e59d88d92b781250b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (9, '2', '3fd40c78c9dcb395b05ad331d9755fc1.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (10, '2', '102e0f05b58c4d3f87e95e2fb017579b.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (12, '3', '89e5eb2e92945a3bb29b1c6f3b3097d7.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (13, '3', '2ccb739cfd4206b8c7b2a2a821dcb7e2.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (14, '3', '23ada7f416ef3d433295070753eb0bb6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (15, '4', '3f72b7d2789b6c8d44b4959ada730da3.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (16, '4', '58cb982c3498154b3f268ce7f4fe43f2.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (17, '4', 'd1171cd0d02a99a01138da6395818124.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (18, '5', '77675ec7414fb3fba0ed2f09c9bb0774.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (19, '5', '3352597badb9d6087c7d44c91be389a6.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (20, '5', 'ee9a8042a0abf483ceb2ed223dc6fd6f.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (21, '5', '27192bca97ffdba2c46ffb6d0a942042.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (22, '5', '53e56fa560cb93055c1ecb55382bf686.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (23, '5', 'ca3999ddfba1a7e533c2332d35a6a1ad.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (24, '6', '5c151a646306a7dd18e3e6177bc321ce.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (25, '6', '4726b0ef22c0c20a1eaecca33d34419e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (26, '6', 'c25ac2b73b6e934e98fa245ba1d61615.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (27, '6', 'f64f9467f5a5f2456f3eb4602aa33e1e.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (28, '6', '1766373597ad1895a5138904d632f609.jpg');
INSERT INTO `app_gallery` (`id`, `id_app_projects`, `fotos`) VALUES (29, '6', '4c2957554816f87af877b31a77bbce3a.jpg');


#
# TABLE STRUCTURE FOR: app_home
#

DROP TABLE IF EXISTS `app_home`;

CREATE TABLE `app_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `legenda_banner` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `banner_imagem` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (1, 'Banner #1', 'Banner Teste', '3963e333e3c60a4baedc6d2a5d360cf0.jpg', 1);
INSERT INTO `app_home` (`id`, `nome_banner`, `legenda_banner`, `banner_imagem`, `ativo`) VALUES (3, 'Banner #2', 'Banner Teste', 'f8b9ceae978beaa4caf4bbdbffb6f163.jpg', 1);


#
# TABLE STRUCTURE FOR: app_projects
#

DROP TABLE IF EXISTS `app_projects`;

CREATE TABLE `app_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `ficha_tecnica` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `localizacao` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `equipe` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `categoria_projeto` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `destaque` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (1, 'CASA R L ', 'Terreno: 2006,00m² <br>\r\nÁrea Construída: 600,00m²', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes', 'Design - Interiores', '4a734b4226afc706d4b0df5bb268544e.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (2, 'CASA D A', 'Terreno: 503,20m² <br>\r\nÁrea Construída: 355,00m² <br>', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Interiores - Design - Casas', 'f0b87c3ec1838fd5e9084bec50bba32c.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (3, ' CASA B A', 'Terreno: 2123,43m² <br>\r\nÁrea Construída: 710,00m²', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Interiores - Design - Construção', 'c82550a4e3d37089b90bde71c8d46bf6.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (4, 'CASA G M', 'Terreno: 2781,50m² <br>\r\nÁrea Construída: 1045,00m² ', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Design - Interiores', 'f2ba9c7c1ddcdfd939df1672fc1e34fb.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (5, 'CASA S R', 'Terreno: 3040,00m² <br>\r\nÁrea Construída: 745,00m²', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Interiores - Design', 'f2e596923160a5e413401fb4bf757ff0.jpg');
INSERT INTO `app_projects` (`id`, `titulo_projeto`, `ficha_tecnica`, `localizacao`, `equipe`, `categoria_projeto`, `destaque`) VALUES (6, 'CASA LAGO', 'Terreno: 2338,24m² <br>\r\nÁrea Construída: 565,00m²', 'Itu / São Paulo', 'Cauê Baldi <br>\r\nJoão Osorio <br>\r\nMarcelo Moretti <br>\r\nFernanda Barreiros <br>\r\nGabriel Curci <br>\r\nCatarina Roland <br>\r\nJaqueline Miranda <br>\r\nMaria Luiza Del Rio <br>\r\nJosé Victor Godoi <br>\r\nGiovanna Passador <br>\r\nMariana Gomes <br>\r\nJulia Arntsen <br>\r\nIanca Carvalho <br>\r\nPedro Antunes <br>', 'Design - Interiores', 'cd154c0917665b1c05d25d2d2215a3cd.jpg');


#
# TABLE STRUCTURE FOR: app_usuarios
#

DROP TABLE IF EXISTS `app_usuarios`;

CREATE TABLE `app_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `senha` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `app_usuarios` (`id`, `nome`, `email`, `senha`, `ativo`) VALUES (3, 'Igor ', 'igor@agenciaduetto.com.br', 'ad108b78d9733dbdf783007c88a08282c9bca427', 1);


